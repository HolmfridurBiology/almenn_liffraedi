/**
 * main.js — Almenn Líffræði Interactive Website
 * Megin JavaScript skrá — Aurora, Quiz, Drag-Drop, Cell, DNA, Food Web
 */

/* ============================================================
   1. BUILD TIMESTAMP
   ============================================================ */
const BUILD_START = Date.now();
const BUILD_DATE  = new Date().toLocaleDateString('is-IS', {
  year: 'numeric', month: 'long', day: 'numeric',
  hour: '2-digit', minute: '2-digit'
});

/* ============================================================
   2. AURORA CANVAS (Northern Lights background)
   ============================================================ */
function initAurora() {
  const canvas = document.getElementById('aurora-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const waves = [
    { y: 0.3, amp: 0.12, freq: 0.0008, speed: 0.00018, phase: 0,   color: [0, 212, 184] },
    { y: 0.5, amp: 0.10, freq: 0.0012, speed: 0.00012, phase: 2.1, color: [74, 222, 128] },
    { y: 0.7, amp: 0.08, freq: 0.0015, speed: 0.00022, phase: 4.3, color: [167, 139, 250] },
  ];

  let t = 0;
  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    waves.forEach(w => {
      ctx.beginPath();
      for (let x = 0; x <= canvas.width; x += 4) {
        const y = canvas.height * w.y +
          Math.sin(x * w.freq + t * w.speed + w.phase) * canvas.height * w.amp +
          Math.sin(x * w.freq * 1.7 + t * w.speed * 1.3) * canvas.height * w.amp * 0.4;
        x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.lineTo(canvas.width, canvas.height);
      ctx.lineTo(0, canvas.height);
      ctx.closePath();
      const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
      grad.addColorStop(0, `rgba(${w.color.join(',')}, 0.18)`);
      grad.addColorStop(1, `rgba(${w.color.join(',')}, 0.0)`);
      ctx.fillStyle = grad;
      ctx.fill();
    });
    t++;
    requestAnimationFrame(draw);
  }
  draw();
}

/* ============================================================
   3. THEME TOGGLE
   ============================================================ */
function initTheme() {
  const btn = document.getElementById('theme-toggle');
  const stored = (() => { try { return localStorage.getItem('liffraedi-theme'); } catch(e){ return null; } })();
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = stored || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
  updateThemeIcon(theme);

  btn && btn.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    updateThemeIcon(next);
    try { localStorage.setItem('liffraedi-theme', next); } catch(e) {}
  });
}
function updateThemeIcon(theme) {
  const btn = document.getElementById('theme-toggle');
  if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
}

/* ============================================================
   4. FONT SIZE
   ============================================================ */
let fontSize = 16;
function initFontSize() {
  const stored = (() => { try { return parseInt(localStorage.getItem('liffraedi-font') || '16'); } catch(e){ return 16; } })();
  fontSize = stored;
  document.documentElement.style.fontSize = fontSize + 'px';

  document.getElementById('font-increase')?.addEventListener('click', () => changeFontSize(1));
  document.getElementById('font-decrease')?.addEventListener('click', () => changeFontSize(-1));
}
function changeFontSize(delta) {
  fontSize = Math.max(12, Math.min(24, fontSize + delta));
  document.documentElement.style.fontSize = fontSize + 'px';
  try { localStorage.setItem('liffraedi-font', fontSize); } catch(e) {}
}

/* ============================================================
   5. LANGUAGE SWITCHER
   ============================================================ */
function initLanguage() {
  const stored = (() => { try { return localStorage.getItem('liffraedi-lang') || 'is'; } catch(e){ return 'is'; } })();
  setLanguage(stored);
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', () => setLanguage(btn.dataset.lang));
  });
}

/* ============================================================
   6. MOBILE MENU TOGGLE
   ============================================================ */
function initMobileMenu() {
  const toggle = document.getElementById('menu-toggle');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');

  toggle?.addEventListener('click', () => {
    const open = sidebar.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
    overlay && overlay.classList.toggle('active', open);
  });

  overlay?.addEventListener('click', () => {
    sidebar.classList.remove('open');
    toggle?.setAttribute('aria-expanded', false);
    overlay.classList.remove('active');
  });

  // Close on nav link click (mobile)
  document.querySelectorAll('#sidebar .nav-item a').forEach(a => {
    a.addEventListener('click', () => {
      if (window.innerWidth <= 768) {
        sidebar.classList.remove('open');
        toggle?.setAttribute('aria-expanded', false);
        overlay?.classList.remove('active');
      }
    });
  });
}

/* ============================================================
   7. ACTIVE NAV LINK (Intersection Observer)
   ============================================================ */
function initActiveNav() {
  const sections = document.querySelectorAll('.chapter-section');
  const navLinks = document.querySelectorAll('#sidebar .nav-item a');

  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const id = e.target.id;
        navLinks.forEach(l => {
          l.classList.toggle('active', l.getAttribute('href') === `#${id}`);
        });
      }
    });
  }, { threshold: 0.3, rootMargin: '-64px 0px 0px 0px' });

  sections.forEach(s => obs.observe(s));
}

/* ============================================================
   8. SCROLL REVEAL
   ============================================================ */
function initScrollReveal() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        obs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

  document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
}

/* ============================================================
   9. QUIZ SYSTEM (reusable)
   Uses data-quiz-id attribute to locate quiz data
   ============================================================ */
const QUIZZES = {
  ch1: [
    {
      q: 'Hvaða lífrænar efnasambönd eru helstu orkugjafar líkamans?',
      opts: ['Fita og prótín','Sykrur (kolvetni) og fita','Vítamín og steinefni','Prótín og vatn'],
      a: 1
    },
    {
      q: 'Hvert eru byggingareiningar prótína?',
      opts: ['Fitusýrur','Glúkósa','Amínósýrur','Fósfat'],
      a: 2
    },
    {
      q: 'Hvaða vítamín frásogast þarfnast fitu til þess?',
      opts: ['B-vítamín','C-vítamín','Fituleysanleg vítamín (A, D, E, K)','Vatnsbætt vítamín'],
      a: 2
    },
    {
      q: 'Hvert er hlutverk meltingarkerfisins?',
      opts: ['Súrefnisflutningur','Hormónaframleiðsla','Sundrun matvæla og frásog næringarefna','Taugaboðflutningur'],
      a: 2
    },
    {
      q: 'Hvaðan kemur meirihluti súrefnis í blóði?',
      opts: ['Meltingarkerfi','Lungu — gegnum öndun','Nýru','Lifur'],
      a: 1
    }
  ],
  ch2: [
    {
      q: 'Hvert er hlutverk hvatbera (mitókondría) í frumunni?',
      opts: ['Ljóstillífun','Prótínmyndun','Orkuframleiðsla (ATP)','Efnaflutnigur'],
      a: 2
    },
    {
      q: 'Hvað er munurinn á dreifkjarna- og kjarnafrumum?',
      opts: ['Stærð einungis','Dreifkjarnafrumur hafa ekki afmarkaðan kjarna','Kjarnafrumur hafa ekki DNA','Dreifkjarnafrumur hafa grænukorn'],
      a: 1
    },
    {
      q: 'Hvað er sérkennandi fyrir plöntufrumur en finnst EKKI í dýrafrumum?',
      opts: ['Hvatberi','Kjarni','Frumuveggur og grænukorn','Frymisnet'],
      a: 2
    },
    {
      q: 'Hvert er hlutverk kjarnans í frumunni?',
      opts: ['Orkuframleiðsla','Geymir erfðaefni og stjórnar frumunni','Ljóstillífun','Frumöndun'],
      a: 1
    },
    {
      q: 'Frumukenningin segir að:',
      opts: ['Allar frumur hafi kjarna','Allar lífverur séu gerðar úr einni eða fleiri frumum','Frumur geti myndast úr dauðu efni','Bakteríur séu ekki lífverur'],
      a: 1
    }
  ],
  ch3: [
    {
      q: 'Hvernig fjölga bakteríur sér?',
      opts: ['Kynæxlun','Gróæxlun','Skiptingu','Með veirur'],
      a: 2
    },
    {
      q: 'Hvað á við um veirur?',
      opts: ['Eru dreifkjarnafrumur','Geta fjölgað sér án hýsils','Eru lífvana smitefni sem þurfa hýsil','Eru stærri en bakteríur'],
      a: 2
    },
    {
      q: 'Hvað er skilyrði rotnunar?',
      opts: ['Kuldinn, þurrki og UV-ljós','Raki, hiti og súrefni','Saltvatn og sýra','Frysting og geislun'],
      a: 1
    },
    {
      q: 'Hvaða kynsjúkdóm er hægt að meðhöndla með sýklalyfjum?',
      opts: ['HIV','HPV (kynfæravörtur)','Klamýdía','Herpes'],
      a: 2
    },
    {
      q: 'Sveppir fjölga sér með:',
      opts: ['Skiptingu','Veirusmiti','Gróum (spórum)','Ljóstillífun'],
      a: 2
    }
  ],
  ch4: [
    {
      q: 'Hvað er gen?',
      opts: ['Gerð prótíns','Hluti af DNA sem kóðar eiginleika','Tegund frumuhimnu','Litni í kjarna'],
      a: 1
    },
    {
      q: 'Hvaða basapar mynda hvort annað í DNA tvöfalda þræðinum?',
      opts: ['A-G og T-C','A-T og G-C','A-C og T-G','A-A og T-T'],
      a: 1
    },
    {
      q: 'Hvaða erfðalög setti Mendel fram?',
      opts: ['Lög um þróun','Lög um erfðir eininga (gen) og aðskilnað þeirra','Lög um stökkbreytingar','Lög um krabbamein'],
      a: 1
    },
    {
      q: 'Hvað er stökkbreyting?',
      opts: ['Venjuleg frumuskipting','Breyting á DNA raðinni','Erfðun eiginleika frá foreldri','Gerð prótíns'],
      a: 1
    },
    {
      q: 'Hvaða frumulíffæri inniheldur DNA í kjarnafrumum?',
      opts: ['Hvatberi','Safabóla','Kjarni','Grænukorn'],
      a: 2
    }
  ],
  ch5: [
    {
      q: 'Hvar á sér frjóvgun stað hjá mönnum?',
      opts: ['Legorð','Legháls','Eggjaleiðara','Eggjastokkur'],
      a: 2
    },
    {
      q: 'Hvaða kynsjúkdómur orsakast af veirum?',
      opts: ['Klamýdía','Sárasótt','HIV og HPV','Lekandi'],
      a: 2
    },
    {
      q: 'Hvað er besta vörn gegn flestum kynsjúkdómum?',
      opts: ['Sýklalyf','Rétt notkun smokks','B-vítamín','Bólusetning gegn öllum sjúkdómum'],
      a: 1
    },
    {
      q: 'Kynfæravörtur orsakast af:',
      opts: ['HIV veirunni','Klamýdíubaktería','HPV veirunni','Trichomónas sníkjudýrinu'],
      a: 2
    },
    {
      q: 'Hvað er bólusetning?',
      opts: ['Sýklalyf gegn bakteríum','Inngjöf veiklaðs smitefnis til að virkja ónæmissvörun','Meðferð við HIV','Hormónameðferð'],
      a: 1
    }
  ],
  ch6: [
    {
      q: 'Hvað eru frumframleiðendur í vistkerfi?',
      opts: ['Dýr sem éta aðrar lífverur','Plöntur og þörungar sem búa til næringu með ljóstillífun','Sveppir sem sundra dauðum lífverum','Bakteríur sem valda sjúkdómum'],
      a: 1
    },
    {
      q: 'Hvað er fæðukeðja?',
      opts: ['Líffærakerfi dýra','Röð lífvera þar sem næringar flyst frá einni til annarrar','Net félagslegra tengsla í náttúrunni','Hringsól kolefnis'],
      a: 1
    },
    {
      q: 'Hvaða þróun á Surtsey er dæmi um?',
      opts: ['Fæðukeðja í lokuðu kerfi','Frumherjun — hvernig líf leggst af á nýju landi','Hamfarahlýnun','Loftslagsbreytingar'],
      a: 1
    },
    {
      q: 'Hvað er hamfarahlýnun?',
      opts: ['Náttúruleg hlýnun sólkerfisins','Hlýnun á loftslagi vegna gróðurhúsalofttegunda frá mannlegum aðgerðum','Kólnun á norðurslóðum','Breytingar á sjávarstreymi'],
      a: 1
    },
    {
      q: 'Hvaða hlutverk hafa rotverar (sundrendur) í vistkerfi?',
      opts: ['Framleiðsla súrefnis','Sundrið lífrænar leifar og skila næringarefnum til jarðvegs','Jafna hitastig hafsins','Binda köfnunarefni úr lofti'],
      a: 1
    }
  ]
};

class Quiz {
  constructor(containerId, quizId) {
    this.el = document.getElementById(containerId);
    this.data = QUIZZES[quizId] || [];
    this.current = 0;
    this.score = 0;
    this.answered = false;
    if (this.el && this.data.length) this.render();
  }

  render() {
    if (this.current >= this.data.length) {
      this.showResult(); return;
    }
    const q = this.data[this.current];
    const dots = this.data.map((_, i) => {
      const cls = i < this.current ? 'done' : (i === this.current ? 'current' : '');
      return `<div class="quiz-dot ${cls}" role="presentation"></div>`;
    }).join('');

    this.el.innerHTML = `
      <div class="quiz-progress" role="progressbar" aria-valuenow="${this.current+1}" aria-valuemax="${this.data.length}" aria-label="Spurning ${this.current+1} af ${this.data.length}">
        ${dots}
      </div>
      <p class="quiz-question" id="quiz-q-${this.current}">${q.q}</p>
      <div class="quiz-options" role="group" aria-labelledby="quiz-q-${this.current}">
        ${q.opts.map((o, i) => `
          <button class="quiz-option" data-idx="${i}" aria-label="${o}">${o}</button>
        `).join('')}
      </div>
      <div class="quiz-feedback" id="quiz-feedback" role="alert" aria-live="polite"></div>
      <button class="quiz-btn" id="quiz-next" disabled data-i18n="quizNext">${t('quizNext')}</button>
    `;
    this.answered = false;
    this.el.querySelectorAll('.quiz-option').forEach(btn => {
      btn.addEventListener('click', () => this.answer(parseInt(btn.dataset.idx)));
    });
    this.el.querySelector('#quiz-next').addEventListener('click', () => {
      this.current++;
      this.render();
    });
  }

  answer(idx) {
    if (this.answered) return;
    this.answered = true;
    const q = this.data[this.current];
    const correct = idx === q.a;
    if (correct) this.score++;

    this.el.querySelectorAll('.quiz-option').forEach((btn, i) => {
      btn.disabled = true;
      if (i === q.a) btn.classList.add('correct');
      else if (i === idx && !correct) btn.classList.add('wrong');
    });

    const fb = this.el.querySelector('#quiz-feedback');
    if (correct) {
      fb.className = 'quiz-feedback show correct';
      fb.textContent = t('quizCorrect');
    } else {
      fb.className = 'quiz-feedback show wrong';
      fb.textContent = t('quizWrong') + q.opts[q.a];
    }

    const nextBtn = this.el.querySelector('#quiz-next');
    if (nextBtn) nextBtn.disabled = false;
  }

  showResult() {
    const pct = Math.round((this.score / this.data.length) * 100);
    const emoji = pct >= 80 ? '🎉' : pct >= 60 ? '👍' : '📚';
    this.el.innerHTML = `
      <div class="quiz-result show">
        <span class="quiz-score-display">${pct}%</span>
        <p class="quiz-result-text">${emoji} ${t('quizScore', {score: this.score, total: this.data.length})}</p>
        <button class="quiz-btn" id="quiz-restart" data-i18n="quizRestart">${t('quizRestart')}</button>
      </div>
    `;
    this.el.querySelector('#quiz-restart').addEventListener('click', () => {
      this.current = 0; this.score = 0;
      this.render();
    });
  }
}

/* ============================================================
   10. NUTRITION DRAG-AND-DROP
   ============================================================ */
const NUTRIENT_DATA = {
  items: [
    { name: '🥩 Prótín', cat: 'lif' },
    { name: '🧈 Fita', cat: 'lif' },
    { name: '🍞 Kolvetni', cat: 'lif' },
    { name: '💊 C-vítamín', cat: 'vit' },
    { name: '🦴 Kalsíum', cat: 'stein' },
    { name: '💉 D-vítamín', cat: 'vit' },
    { name: '🩸 Járn', cat: 'stein' },
    { name: '🧪 B12-vítamín', cat: 'vit' },
    { name: '🥜 Omega-3', cat: 'lif' },
  ],
  categories: {
    lif:   { label: '⚗️ Lífræn efni', subtitle: 'Kolvetni, fita, prótín' },
    vit:   { label: '💊 Vítamín', subtitle: 'Leysanleg í vatni eða fitu' },
    stein: { label: '🔩 Steinefni', subtitle: 'Ólífræn efni' }
  }
};

function initNutritionDrag() {
  const container = document.getElementById('nutrition-drag');
  if (!container) return;

  const shuffled = [...NUTRIENT_DATA.items].sort(() => Math.random() - 0.5);
  const cats = NUTRIENT_DATA.categories;

  container.innerHTML = `
    <div class="drag-container">
      <div class="drag-source" id="drag-pool">
        <h4>🧪 Næringarefni</h4>
        ${shuffled.map(item => `
          <div class="drag-item" draggable="true" data-cat="${item.cat}" data-name="${item.name}"
            tabindex="0" role="button" aria-grabbed="false" aria-label="Dragðu: ${item.name}">
            ${item.name}
          </div>
        `).join('')}
      </div>
      ${Object.entries(cats).map(([key, cat]) => `
        <div class="drop-zone" id="drop-${key}" data-cat="${key}">
          <h4>${cat.label}</h4>
          <small style="color:var(--text-muted);font-size:0.68rem;">${cat.subtitle}</small>
          <div class="drop-area" style="margin-top:0.5rem;min-height:60px;"></div>
        </div>
      `).join('')}
    </div>
    <div class="drag-feedback" id="drag-feedback"></div>
  `;

  let dragSrc = null;

  container.querySelectorAll('.drag-item').forEach(item => {
    item.addEventListener('dragstart', e => {
      dragSrc = item;
      item.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', item.dataset.cat);
    });
    item.addEventListener('dragend', () => {
      item.classList.remove('dragging');
      dragSrc = null;
    });

    // Keyboard accessibility
    item.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        // highlight drop zones
        container.querySelectorAll('.drop-zone').forEach(z => z.style.outline = '2px dashed var(--accent-teal)');
      }
    });
  });

  container.querySelectorAll('.drop-zone').forEach(zone => {
    zone.addEventListener('dragover', e => {
      e.preventDefault();
      zone.classList.add('drag-over');
      e.dataTransfer.dropEffect = 'move';
    });
    zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
    zone.addEventListener('drop', e => {
      e.preventDefault();
      zone.classList.remove('drag-over');
      if (!dragSrc) return;

      const srcCat  = dragSrc.dataset.cat;
      const zoneCat = zone.dataset.cat;
      const correct = srcCat === zoneCat;

      const area = zone.querySelector('.drop-area') || zone;
      area.appendChild(dragSrc);
      dragSrc.draggable = false;
      dragSrc.style.cursor = 'default';

      zone.classList.add(correct ? 'correct' : 'wrong');
      setTimeout(() => zone.classList.remove('correct', 'wrong'), 1000);

      // Feedback
      const fb = container.querySelector('#drag-feedback');
      if (fb) {
        const placed = container.querySelectorAll('.drag-item:not(#drag-pool .drag-item)').length;
        const total  = NUTRIENT_DATA.items.length;
        if (placed === total) {
          const allCorrect = [...container.querySelectorAll('.drop-zone')].every(z => {
            const zCat = z.dataset.cat;
            return [...z.querySelectorAll('.drag-item')].every(i => i.dataset.cat === zCat);
          });
          fb.className = `drag-feedback show ${allCorrect ? 'success' : 'error'}`;
          fb.textContent = allCorrect ? '🎉 Allt rétt! Frábært!' : '🔄 Nokkur mistök — prófaðu aftur!';
        }
      }
    });
  });
}

/* ============================================================
   11. INTERACTIVE CELL DIAGRAM (SVG-based)
   ============================================================ */
const ORGANELLE_INFO = {
  hvatberi:  { icon: '⚡', name: 'Hvatberi (Mitókondría)', desc: 'Orkuver frumunnar. Framleið ATP úr glúkósa og súrefni með frumöndun.' },
  kjarni:    { icon: '🧬', name: 'Kjarni (Kjarna)', desc: 'Stjórnstöð frumunnar. Geymir DNA (erfðaefnið) og stjórnar starfsemi frumunnar.' },
  frymisflet: { icon: '📦', name: 'Frymisflétta (Golgi)', desc: 'Pósthúsið. Meðhöndlar og flytur prótín og önnur efni út úr frumunni.' },
  ribosom:   { icon: '🔩', name: 'Netkorn (Ríbósóm)', desc: 'Prótínverksmiðjan. Les RNA og sameinar amínósýrur í prótín.' },
  grænukorn: { icon: '☀️', name: 'Grænukorn (Kloroplastur)', desc: 'Ljóstillífunarvél — er AÐEINS í plöntufrumum. Breytir sólarljósi í sykur.' },
  frumuhimna:{ icon: '🚧', name: 'Frumuhimna (Plasmalemma)', desc: 'Hlið frumunnar. Stýrir hvað fer inn og út úr frumunni.' },
  frymisnet: { icon: '🌐', name: 'Frymisnet (ER)', desc: 'Flutninga- og framleiðslukerfi. Hrjúft ER sameinar prótín, slétt ER framleiðir fitu.' },
  safabola:  { icon: '💧', name: 'Safabóla (Vacuole)', desc: 'Geymslutankur — sérstaklega stór í plöntufrumum, heldur þrýstingi.' },
};

function initCellDiagram() {
  const wrap = document.getElementById('cell-diagram');
  if (!wrap) return;

  wrap.innerHTML = `
    <div class="cell-diagram-wrap">
      <svg viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Gagnvirkt frumurit — smelltu á hluta">
        <!-- Cell membrane -->
        <ellipse cx="200" cy="155" rx="185" ry="130" fill="rgba(0,212,184,0.04)" stroke="var(--accent-teal)" stroke-width="2.5" stroke-dasharray="6 3"/>
        <!-- Cell wall (plant) -->
        <ellipse cx="200" cy="155" rx="192" ry="137" fill="none" stroke="var(--accent-green)" stroke-width="1.5" opacity="0.4"/>

        <!-- Nucleus -->
        <g class="organelle-area" data-org="kjarni" tabindex="0" role="button" aria-label="Kjarni">
          <ellipse cx="200" cy="150" rx="52" ry="42" fill="rgba(167,139,250,0.18)" stroke="var(--accent-purple)" stroke-width="2"/>
          <ellipse cx="200" cy="150" rx="22" ry="18" fill="rgba(167,139,250,0.35)" stroke="var(--accent-purple)" stroke-width="1.5"/>
          <text x="200" y="195" text-anchor="middle" font-size="9" fill="var(--accent-purple)" font-family="Verdana">Kjarni</text>
        </g>

        <!-- Mitochondria x2 -->
        <g class="organelle-area" data-org="hvatberi" tabindex="0" role="button" aria-label="Hvatberi">
          <ellipse cx="90" cy="110" rx="28" ry="16" fill="rgba(240,165,0,0.2)" stroke="var(--accent-gold)" stroke-width="1.5" transform="rotate(-20,90,110)"/>
          <text x="90" y="137" text-anchor="middle" font-size="8" fill="var(--accent-gold)" font-family="Verdana">Hvatberi</text>
          <ellipse cx="330" cy="195" rx="24" ry="13" fill="rgba(240,165,0,0.2)" stroke="var(--accent-gold)" stroke-width="1.5" transform="rotate(15,330,195)"/>
        </g>

        <!-- Golgi apparatus -->
        <g class="organelle-area" data-org="frymisflet" tabindex="0" role="button" aria-label="Frymisflétta">
          <path d="M285,120 Q320,120 315,135 Q320,150 285,150" fill="none" stroke="var(--accent-pink)" stroke-width="2"/>
          <path d="M285,127 Q315,127 310,140 Q315,152 285,152" fill="none" stroke="var(--accent-pink)" stroke-width="2"/>
          <text x="305" y="165" text-anchor="middle" font-size="8" fill="var(--accent-pink)" font-family="Verdana">Frymisflétta</text>
        </g>

        <!-- ER (rough) -->
        <g class="organelle-area" data-org="frymisnet" tabindex="0" role="button" aria-label="Frymisnet">
          <path d="M140,75 Q170,65 190,85 Q210,100 235,90" fill="none" stroke="rgba(56,189,248,0.8)" stroke-width="2" stroke-dasharray="4 2"/>
          <text x="185" y="62" text-anchor="middle" font-size="8" fill="rgb(56,189,248)" font-family="Verdana">Frymisnet</text>
        </g>

        <!-- Ribosomes (dots) -->
        <g class="organelle-area" data-org="ribosom" tabindex="0" role="button" aria-label="Netkorn">
          <circle cx="155" cy="108" r="4" fill="var(--accent-gold)" opacity="0.7"/>
          <circle cx="165" cy="115" r="4" fill="var(--accent-gold)" opacity="0.7"/>
          <circle cx="145" cy="118" r="4" fill="var(--accent-gold)" opacity="0.7"/>
          <circle cx="160" cy="125" r="4" fill="var(--accent-gold)" opacity="0.7"/>
          <text x="120" y="140" text-anchor="middle" font-size="8" fill="var(--accent-gold)" font-family="Verdana">Netkorn</text>
        </g>

        <!-- Vacuole -->
        <g class="organelle-area" data-org="safabola" tabindex="0" role="button" aria-label="Safabóla">
          <ellipse cx="120" cy="205" rx="35" ry="28" fill="rgba(56,189,248,0.12)" stroke="rgba(56,189,248,0.6)" stroke-width="1.5"/>
          <text x="120" y="240" text-anchor="middle" font-size="8" fill="rgb(56,189,248)" font-family="Verdana">Safabóla</text>
        </g>

        <!-- Chloroplast (plant only) -->
        <g class="organelle-area" data-org="grænukorn" tabindex="0" role="button" aria-label="Grænukorn">
          <ellipse cx="305" cy="230" rx="32" ry="18" fill="rgba(74,222,128,0.2)" stroke="var(--accent-green)" stroke-width="1.5"/>
          <ellipse cx="305" cy="230" rx="20" ry="10" fill="rgba(74,222,128,0.3)" stroke="var(--accent-green)" stroke-width="1"/>
          <text x="305" y="255" text-anchor="middle" font-size="8" fill="var(--accent-green)" font-family="Verdana">Grænukorn ☘️</text>
        </g>

        <!-- Cell membrane label -->
        <text x="20" y="80" font-size="7.5" fill="var(--accent-teal)" font-family="Verdana" class="organelle-area" data-org="frumuhimna" tabindex="0" style="cursor:pointer">
          ← Frumuhimna
        </text>
      </svg>
      <div class="organelle-info" id="organelle-info">
        <span class="organelle-info-icon">🔬</span>
        <div class="organelle-info-text">
          <strong data-i18n="cellClick">Smelltu á frumulíffæri til að fá upplýsingar</strong>
        </div>
      </div>
    </div>
  `;

  const infoBox = wrap.querySelector('#organelle-info');
  wrap.querySelectorAll('.organelle-area').forEach(el => {
    const handler = () => {
      const key = el.dataset.org;
      const info = ORGANELLE_INFO[key];
      if (!info) return;
      infoBox.innerHTML = `
        <span class="organelle-info-icon">${info.icon}</span>
        <div class="organelle-info-text">
          <strong>${info.name}</strong>
          ${info.desc}
        </div>
      `;
      // Pulse animation
      infoBox.style.animation = 'none';
      infoBox.offsetHeight; // reflow
      infoBox.style.animation = 'fadeInUp 0.3s ease';
    };
    el.addEventListener('click', handler);
    el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handler(); } });
  });
}

/* ============================================================
   12. DNA BASE PAIR MATCHING GAME
   ============================================================ */
function initDNAGame() {
  const container = document.getElementById('dna-game');
  if (!container) return;

  const PAIRS = { A: 'T', T: 'A', G: 'C', C: 'G' };
  const COLORS = { A: 'A', T: 'T', G: 'G', C: 'C' };
  const strand1 = ['A', 'T', 'G', 'C', 'A', 'G'];
  const strand2 = strand1.map(b => PAIRS[b]);
  const shuffled2 = [...strand2].sort(() => Math.random() - 0.5);

  let selected1 = null;
  let selected2 = null;
  let matched = new Set();
  let score = 0;

  function render() {
    container.innerHTML = `
      <div class="dna-game">
        <div class="dna-strand" id="dna-s1">
          ${strand1.map((b, i) => `
            <div class="dna-base ${COLORS[b]} ${matched.has(i) ? 'matched' : ''}"
              data-idx="${i}" data-base="${b}" data-strand="1"
              tabindex="${matched.has(i) ? '-1' : '0'}" role="button"
              aria-label="Base ${b}" aria-pressed="false">
              ${b}
            </div>
          `).join('')}
        </div>
        <div class="dna-connector">
          ${strand1.map((_, i) => `
            <div class="dna-bond ${matched.has(i) ? 'bonded' : ''}" title="${matched.has(i) ? '✓' : '?'}">
              ${matched.has(i) ? '≡' : ''}
            </div>
          `).join('')}
        </div>
        <div class="dna-strand" id="dna-s2">
          ${shuffled2.map((b, i) => `
            <div class="dna-base ${COLORS[b]} ${[...matched].map(m => strand2.indexOf(strand2[m])).includes(i) ? 'matched' : ''}"
              data-idx="${i}" data-base="${b}" data-strand="2"
              tabindex="0" role="button"
              aria-label="Base ${b}" aria-pressed="false">
              ${b}
            </div>
          `).join('')}
        </div>
      </div>
      <div style="text-align:center;margin-top:1rem;font-size:0.8rem;color:var(--text-muted)">
        ${score}/${strand1.length} pör fundið 🧬
      </div>
    `;

    container.querySelectorAll('.dna-base').forEach(el => {
      if (el.classList.contains('matched')) return;
      el.addEventListener('click', () => handleBaseClick(el));
      el.addEventListener('keydown', e => { if (e.key==='Enter'||e.key===' ') { e.preventDefault(); handleBaseClick(el); } });
    });
  }

  function handleBaseClick(el) {
    const strand = el.dataset.strand;
    const base   = el.dataset.base;
    const idx    = parseInt(el.dataset.idx);

    if (strand === '1') {
      if (selected1) selected1.classList.remove('selected');
      selected1 = el;
      el.classList.add('selected');
    } else {
      if (selected2) selected2.classList.remove('selected');
      selected2 = el;
      el.classList.add('selected');
    }

    // Check pair
    if (selected1 && selected2) {
      const s1base = selected1.dataset.base;
      const s2base = selected2.dataset.base;
      const correct = PAIRS[s1base] === s2base;

      selected1.classList.add(correct ? 'correct-flash' : 'wrong-flash');
      selected2.classList.add(correct ? 'correct-flash' : 'wrong-flash');

      if (correct) {
        const idx1 = parseInt(selected1.dataset.idx);
        matched.add(idx1);
        score++;
        setTimeout(() => {
          selected1 = selected2 = null;
          render();
          if (score === strand1.length) {
            container.innerHTML += `<div style="text-align:center;padding:1rem;color:var(--accent-green);font-weight:bold;animation:fadeInUp 0.5s ease">🎉 Öll basapör fundin! DNA keðjan er fullkomin!</div>`;
          }
        }, 500);
      } else {
        setTimeout(() => {
          selected1.classList.remove('selected', 'wrong-flash');
          selected2.classList.remove('selected', 'wrong-flash');
          selected1 = selected2 = null;
        }, 700);
      }
    }
  }

  render();
}

/* ============================================================
   13. FOOD WEB DRAG-AND-DROP (Ch6)
   ============================================================ */
const FOOD_WEB_ORGANISMS = [
  { name: '🌿 Mosi', level: 'prod' },
  { name: '🌾 Gras', level: 'prod' },
  { name: '🐛 Myglusveppur', level: 'rot' },
  { name: '🐭 Mús', level: 'herb' },
  { name: '🐑 Sauðfé', level: 'herb' },
  { name: '🦊 Melrakki', level: 'carn' },
  { name: '🦅 Heiðagæir', level: 'carn' },
  { name: '🍄 Sveppur', level: 'rot' },
];

function initFoodWeb() {
  const container = document.getElementById('food-web');
  if (!container) return;

  const levels = [
    { key: 'prod', label: '🌿 Frumframleiðendur', hint: 'Plöntur, þörungar' },
    { key: 'herb', label: '🐑 Grasætur', hint: 'Éta plöntur' },
    { key: 'carn', label: '🦊 Rándýr', hint: 'Éta önnur dýr' },
    { key: 'rot',  label: '🍄 Rotverar', hint: 'Sundra dauðum efnum' },
  ];

  const shuffled = [...FOOD_WEB_ORGANISMS].sort(() => Math.random() - 0.5);

  container.innerHTML = `
    <div class="food-web-container">
      <div style="display:flex;flex-wrap:wrap;gap:0.4rem;margin-bottom:1rem;padding:0.75rem;background:var(--bg-glass);border-radius:var(--radius);border:1px solid var(--border)">
        <span style="font-size:0.72rem;color:var(--text-muted);width:100%;margin-bottom:0.25rem">Dragðu lífverur í réttan flokk 👇</span>
        ${shuffled.map(o => `
          <div class="drag-item" draggable="true" data-level="${o.level}" tabindex="0" role="button">${o.name}</div>
        `).join('')}
      </div>
      <div class="food-web-grid">
        ${levels.map(l => `
          <div class="trophic-level" data-level="${l.key}">
            <h5>${l.label}</h5>
            <small style="color:var(--text-muted);font-size:0.68rem">${l.hint}</small>
            <div class="drop-area" data-level="${l.key}"></div>
          </div>
        `).join('')}
      </div>
      <div id="fw-feedback" class="drag-feedback"></div>
    </div>
  `;

  let dragSrc = null;

  container.querySelectorAll('.drag-item').forEach(item => {
    item.addEventListener('dragstart', e => {
      dragSrc = item;
      item.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    });
    item.addEventListener('dragend', () => {
      item.classList.remove('dragging');
      dragSrc = null;
    });
  });

  container.querySelectorAll('.drop-area').forEach(area => {
    area.addEventListener('dragover', e => { e.preventDefault(); area.classList.add('drag-over'); });
    area.addEventListener('dragleave', () => area.classList.remove('drag-over'));
    area.addEventListener('drop', e => {
      e.preventDefault();
      area.classList.remove('drag-over');
      if (!dragSrc) return;

      const correct = dragSrc.dataset.level === area.dataset.level;
      area.appendChild(dragSrc);
      dragSrc.draggable = false;
      dragSrc.style.cursor = 'default';
      dragSrc.style.background = correct ? 'rgba(74,222,128,0.15)' : 'rgba(244,114,182,0.15)';
      dragSrc.style.borderColor = correct ? 'var(--accent-green)' : 'var(--accent-pink)';

      // Check if all placed
      const placed = container.querySelectorAll('.trophic-level .drag-item').length;
      if (placed === FOOD_WEB_ORGANISMS.length) {
        const allCorrect = [...container.querySelectorAll('.trophic-level')].every(tl => {
          const lvl = tl.dataset.level;
          return [...tl.querySelectorAll('.drag-item')].every(i => i.dataset.level === lvl);
        });
        const fb = container.querySelector('#fw-feedback');
        fb.className = `drag-feedback show ${allCorrect ? 'success' : 'error'}`;
        fb.textContent = allCorrect
          ? '🌍 Frábært! Þú smíðaðir nákvæman fæðuvef!'
          : '🔄 Nokkur efni eru í röngum flokkum — skoðaðu aftur!';
      }
    });
  });
}

/* ============================================================
   14. FOOTER TIMESTAMP
   ============================================================ */
function initFooter() {
  const buildEl = document.getElementById('footer-build-date');
  if (buildEl) buildEl.textContent = BUILD_DATE;

  // Calculate build time (simulated — actual page load time)
  const loadTime = ((Date.now() - performance.timing.navigationStart) / 1000).toFixed(1);
  const timeEl = document.getElementById('footer-build-time');
  if (timeEl) timeEl.textContent = '~45 mínútur';
}

/* ============================================================
   15. ENTRY POINT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  initAurora();
  initTheme();
  initFontSize();
  initLanguage();
  initMobileMenu();
  initActiveNav();
  initScrollReveal();
  initNutritionDrag();
  initCellDiagram();
  initDNAGame();
  initFoodWeb();
  initFooter();

  // Initialize all quizzes
  document.querySelectorAll('[data-quiz]').forEach(el => {
    new Quiz(el.id, el.dataset.quiz);
  });
});
