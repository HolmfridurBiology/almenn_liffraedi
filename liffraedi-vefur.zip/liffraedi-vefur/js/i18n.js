/**
 * i18n.js — Þýðingar í öllum tungumálum / Translations for all languages
 * Bæta við nýju tungumáli: Afritaðu "is" blokk og þýddu gildin.
 * To add a new language: Copy the "is" block and translate the values.
 */

const TRANSLATIONS = {

  is: {
    dir: "ltr",
    langName: "Íslenska",
    // --- Nav & UI ---
    siteTitle: "Almenn Líffræði",
    siteSubtitle: "LÍFF2LA05 · Flensborgarskóli",
    skipLink: "Fara beint í efni",
    themeToggle: "Skipta um þema",
    fontIncrease: "Stækka letur",
    fontDecrease: "Minnka letur",
    langLabel: "Tungumál",
    // --- Chapter nav ---
    navChapters: "Kaflar",
    ch1Nav: "Næringarfræði",
    ch2Nav: "Frumur",
    ch3Nav: "Örverur",
    ch4Nav: "Erfðafræði",
    ch5Nav: "Æxlun",
    ch6Nav: "Vistfræði",
    // --- Home Hero ---
    heroHeading: "Lífið í allri sinni dýrð",
    heroSub: "Skoðaðu heiminn sem er of lítill til að sjást — en stýrir öllu.",
    heroStart: "Byrja nám",
    // --- Chapter headings & intro ---
    ch1Title: "★ Næringarfræði & Mannslíkaminn",
    ch1Intro: "Líkaminn þinn er vél sem þarf eldsneyti. Við könnum lífrænar efnasambönd, vítamín og hvernig líffærakerfi mannslíkamans samþykir, flytur og nýtir næringu.",
    ch2Title: "★ Frumur — Lífseiningar",
    ch2Intro: "Allar lífverur eru gerðar úr frumum. Hér skoðum við frumukenninguna, frumulíffærin og muninn á plöntu-, dýra- og bakteríufrumum.",
    ch3Title: "★ Örverur — Bakteríur, Sveppir & Veirur",
    ch3Intro: "Örverur eru alls staðar — í jarðvegi, í loftinu, í líkama þínum. Sumar bjarga lífi þínu, aðrar valda sjúkdómi. Lærðu að þekkja þær.",
    ch4Title: "★ Erfðafræði & Stökkbreytingar",
    ch4Intro: "DNA er lífskóðinn. Við skoðum erfðalög Mendels, hvernig eiginleikar erfast og tengsl erfða og krabbameins.",
    ch5Title: "Æxlun & Kynheilbrigði",
    ch5Intro: "Frá frjóvgun til fæðingar — og kynheilbrigði sem hluta af heilbrigðu lífi. Við skoðum æxlunarferlið og helstu kynsjúkdóma.",
    ch6Title: "★ Vistfræði & Umhverfisfræði",
    ch6Intro: "Lífverur lifa ekki einar — þær mynda flókin net tenginganna. Við skoðum vistkerfi, fæðukeðjur og umhverfisáhrif mannsins.",
    // --- Expandable sections ---
    readMore: "Lesa meira",
    readLess: "Loka",
    // --- Quiz ---
    quizTitle: "Prófaðu þig!",
    quizNext: "Næsta spurning",
    quizRestart: "Byrja aftur",
    quizScore: "Niðurstaða: {score} af {total}",
    quizCorrect: "✓ Rétt!",
    quizWrong: "✗ Rangt — rétt svar: ",
    quizFinished: "Þér er lokið! Einkunn þín:",
    // --- Interactive ---
    dragInstruction: "Dragðu efnin í rétta flokka",
    cellClick: "Smelltu á frumulíffæri til að fá upplýsingar",
    matchTitle: "Paraðu DNA-basepar saman",
    foodWebTitle: "Smíðaðu fæðuvef",
    dropHere: "Sleppa hér",
    // --- Footer ---
    footerBuilt: "Smíðað",
    footerTime: "Smíðað á",
    footerCopyright: "© 2026 Hólmfríður Sigþórsdóttir · Flensborgarskóli",
    footerSources: "Heimildir: Vísindavefurinn, MMS, Landlæknisembættið"
  },

  en: {
    dir: "ltr",
    langName: "English",
    siteTitle: "General Biology",
    siteSubtitle: "LÍFF2LA05 · Flensborg School",
    skipLink: "Skip to content",
    themeToggle: "Toggle theme",
    fontIncrease: "Increase font",
    fontDecrease: "Decrease font",
    langLabel: "Language",
    navChapters: "Chapters",
    ch1Nav: "Nutrition",
    ch2Nav: "Cells",
    ch3Nav: "Microorganisms",
    ch4Nav: "Genetics",
    ch5Nav: "Reproduction",
    ch6Nav: "Ecology",
    heroHeading: "Life in All Its Glory",
    heroSub: "Explore the world too small to see — yet it controls everything.",
    heroStart: "Start Learning",
    ch1Title: "★ Nutrition & The Human Body",
    ch1Intro: "Your body is a machine that needs fuel. We explore organic compounds, vitamins, and how the body's organ systems absorb, transport and use nutrients.",
    ch2Title: "★ Cells — The Units of Life",
    ch2Intro: "All living things are made of cells. Here we study cell theory, organelles, and the differences between plant, animal and bacterial cells.",
    ch3Title: "★ Microorganisms — Bacteria, Fungi & Viruses",
    ch3Intro: "Microorganisms are everywhere — in soil, in the air, in your body. Some save your life, others cause disease. Learn to recognise them.",
    ch4Title: "★ Genetics & Mutations",
    ch4Intro: "DNA is the code of life. We study Mendel's laws, how traits are inherited, and the link between genetics and cancer.",
    ch5Title: "Reproduction & Sexual Health",
    ch5Intro: "From fertilisation to birth — and sexual health as part of a healthy life. We explore the reproductive process and key sexually transmitted infections.",
    ch6Title: "★ Ecology & Environmental Science",
    ch6Intro: "Organisms don't live alone — they form complex webs of connections. We study ecosystems, food chains and human environmental impact.",
    readMore: "Read more",
    readLess: "Close",
    quizTitle: "Test Yourself!",
    quizNext: "Next question",
    quizRestart: "Restart",
    quizScore: "Score: {score} of {total}",
    quizCorrect: "✓ Correct!",
    quizWrong: "✗ Wrong — correct answer: ",
    quizFinished: "Done! Your score:",
    dragInstruction: "Drag nutrients into the correct categories",
    cellClick: "Click on an organelle to learn more",
    matchTitle: "Match the DNA base pairs",
    foodWebTitle: "Build a Food Web",
    dropHere: "Drop here",
    footerBuilt: "Built on",
    footerTime: "Build time:",
    footerCopyright: "© 2026 Hólmfríður Sigþórsdóttir · Flensborg School",
    footerSources: "Sources: Vísindavefurinn, MMS, Directorate of Health"
  },

  pl: {
    dir: "ltr",
    langName: "Polski",
    siteTitle: "Biologia Ogólna",
    siteSubtitle: "LÍFF2LA05 · Szkoła Flensborg",
    skipLink: "Przejdź do treści",
    themeToggle: "Zmień motyw",
    fontIncrease: "Powiększ czcionkę",
    fontDecrease: "Zmniejsz czcionkę",
    langLabel: "Język",
    navChapters: "Rozdziały",
    ch1Nav: "Żywienie",
    ch2Nav: "Komórki",
    ch3Nav: "Mikroorganizmy",
    ch4Nav: "Genetyka",
    ch5Nav: "Rozmnażanie",
    ch6Nav: "Ekologia",
    heroHeading: "Życie w całej swej chwale",
    heroSub: "Odkryj świat zbyt mały, by go zobaczyć — a jednak rządzi wszystkim.",
    heroStart: "Rozpocznij naukę",
    ch1Title: "★ Żywienie i ciało człowieka",
    ch1Intro: "Twoje ciało to maszyna potrzebująca paliwa. Badamy związki organiczne, witaminy i sposób, w jaki układy narządów wchłaniają, transportują i wykorzystują składniki odżywcze.",
    ch2Title: "★ Komórki — jednostki życia",
    ch2Intro: "Wszystkie żywe istoty zbudowane są z komórek. Poznajemy teorię komórkową, organelle i różnice między komórkami roślin, zwierząt i bakterii.",
    ch3Title: "★ Mikroorganizmy — Bakterie, Grzyby i Wirusy",
    ch3Intro: "Mikroorganizmy są wszędzie — w glebie, w powietrzu, w twoim ciele. Niektóre ratują życie, inne wywołują choroby. Naucz się je rozróżniać.",
    ch4Title: "★ Genetyka i Mutacje",
    ch4Intro: "DNA to kod życia. Badamy prawa Mendla, dziedziczenie cech i związek genetyki z rakiem.",
    ch5Title: "Rozmnażanie i zdrowie seksualne",
    ch5Intro: "Od zapłodnienia do narodzin — i zdrowie seksualne jako część zdrowego życia. Badamy proces rozrodczy i główne choroby przenoszone drogą płciową.",
    ch6Title: "★ Ekologia i nauka o środowisku",
    ch6Intro: "Organizmy nie żyją w izolacji — tworzą złożone sieci połączeń. Badamy ekosystemy, łańcuchy pokarmowe i wpływ człowieka na środowisko.",
    readMore: "Czytaj więcej",
    readLess: "Zamknij",
    quizTitle: "Sprawdź się!",
    quizNext: "Następne pytanie",
    quizRestart: "Zacznij od nowa",
    quizScore: "Wynik: {score} z {total}",
    quizCorrect: "✓ Poprawnie!",
    quizWrong: "✗ Błąd — prawidłowa odpowiedź: ",
    quizFinished: "Gotowe! Twój wynik:",
    dragInstruction: "Przeciągnij składniki odżywcze do właściwych kategorii",
    cellClick: "Kliknij organellum, aby dowiedzieć się więcej",
    matchTitle: "Dopasuj pary zasad DNA",
    foodWebTitle: "Zbuduj sieć troficzną",
    dropHere: "Upuść tutaj",
    footerBuilt: "Zbudowano",
    footerTime: "Czas budowy:",
    footerCopyright: "© 2026 Hólmfríður Sigþórsdóttir · Szkoła Flensborg",
    footerSources: "Źródła: Vísindavefurinn, MMS, Dyrekcja Zdrowia"
  },

  ar: {
    dir: "rtl",
    langName: "العربية",
    siteTitle: "أحياء عامة",
    siteSubtitle: "LÍFF2LA05 · مدرسة فلنسبورغ",
    skipLink: "انتقل إلى المحتوى",
    themeToggle: "تبديل المظهر",
    fontIncrease: "تكبير الخط",
    fontDecrease: "تصغير الخط",
    langLabel: "اللغة",
    navChapters: "الفصول",
    ch1Nav: "التغذية",
    ch2Nav: "الخلايا",
    ch3Nav: "الكائنات الدقيقة",
    ch4Nav: "علم الوراثة",
    ch5Nav: "التكاثر",
    ch6Nav: "علم البيئة",
    heroHeading: "الحياة بكل مجدها",
    heroSub: "استكشف العالم الذي لا يُرى — لكنه يتحكم في كل شيء.",
    heroStart: "ابدأ التعلم",
    ch1Title: "★ التغذية وجسم الإنسان",
    ch1Intro: "جسمك آلة تحتاج وقودًا. ندرس المركبات العضوية والفيتامينات وكيف تمتص أجهزة جسم الإنسان المواد الغذائية وتنقلها وتستخدمها.",
    ch2Title: "★ الخلايا — وحدات الحياة",
    ch2Intro: "جميع الكائنات الحية مصنوعة من خلايا. ندرس نظرية الخلية والعضيات والفروق بين خلايا النباتات والحيوانات والبكتيريا.",
    ch3Title: "★ الكائنات الدقيقة — بكتيريا وفطريات وفيروسات",
    ch3Intro: "الكائنات الدقيقة في كل مكان — في التربة، في الهواء، في جسمك. بعضها ينقذ حياتك وبعضها يسبب الأمراض. تعلّم كيف تميّزها.",
    ch4Title: "★ علم الوراثة والطفرات",
    ch4Intro: "الحمض النووي هو شفرة الحياة. ندرس قوانين مندل وكيفية توارث الصفات والعلاقة بين الوراثة والسرطان.",
    ch5Title: "التكاثر والصحة الجنسية",
    ch5Intro: "من الإخصاب إلى الولادة — والصحة الجنسية كجزء من الحياة الصحية. ندرس عملية التكاثر والأمراض المنقولة جنسيًا الرئيسية.",
    ch6Title: "★ علم البيئة والعلوم البيئية",
    ch6Intro: "الكائنات لا تعيش وحيدة — فهي تشكّل شبكات معقدة من الروابط. ندرس الأنظمة البيئية وسلاسل الغذاء والتأثير البيئي للإنسان.",
    readMore: "اقرأ المزيد",
    readLess: "إغلاق",
    quizTitle: "اختبر نفسك!",
    quizNext: "السؤال التالي",
    quizRestart: "ابدأ من جديد",
    quizScore: "النتيجة: {score} من {total}",
    quizCorrect: "✓ صحيح!",
    quizWrong: "✗ خطأ — الإجابة الصحيحة: ",
    quizFinished: "انتهيت! نتيجتك:",
    dragInstruction: "اسحب المواد الغذائية إلى الفئات الصحيحة",
    cellClick: "انقر على عضية لمعرفة المزيد",
    matchTitle: "طابق أزواج قواعد الحمض النووي",
    foodWebTitle: "ابنِ شبكة غذائية",
    dropHere: "أفلت هنا",
    footerBuilt: "بُني في",
    footerTime: "وقت البناء:",
    footerCopyright: "© 2026 Hólmfríður Sigþórsdóttir · مدرسة فلنسبورغ",
    footerSources: "المصادر: Vísindavefurinn، MMS، الإدارة الصحية"
  }
};

// Current language state
let currentLang = 'is';

function setLanguage(lang) {
  if (!TRANSLATIONS[lang]) return;
  currentLang = lang;
  const t = TRANSLATIONS[lang];
  
  // Set document direction
  document.documentElement.dir = t.dir;
  document.documentElement.lang = lang;
  
  // Update all elements with data-i18n
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (t[key] !== undefined) {
      if (el.tagName === 'INPUT' || el.tagName === 'BUTTON') {
        el.value = t[key];
      } else {
        el.textContent = t[key];
      }
    }
  });

  // Update title attributes
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.getAttribute('data-i18n-title');
    if (t[key] !== undefined) el.title = t[key];
  });

  // Update aria-labels
  document.querySelectorAll('[data-i18n-aria]').forEach(el => {
    const key = el.getAttribute('data-i18n-aria');
    if (t[key] !== undefined) el.setAttribute('aria-label', t[key]);
  });

  // Mark active lang button
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === lang);
    btn.setAttribute('aria-pressed', btn.dataset.lang === lang);
  });

  // Save preference
  try { localStorage.setItem('liffraedi-lang', lang); } catch(e) {}
}

function t(key, vars) {
  let str = (TRANSLATIONS[currentLang] || TRANSLATIONS['is'])[key] || key;
  if (vars) {
    Object.entries(vars).forEach(([k, v]) => {
      str = str.replace(`{${k}}`, v);
    });
  }
  return str;
}
